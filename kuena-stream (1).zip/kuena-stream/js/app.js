"use strict";
const $ = (s, r = document) => r.querySelector(s), page = document.body.dataset.page, KEY = "kuena-mylist", RK = "kuena-recent";
const rd = k => { try { return JSON.parse(localStorage.getItem(k)) || []; } catch (e) { return []; } };
const wr = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage blocked */ } };
let titles = [], list = rd(KEY), recent = rd(RK), cur = null, slide = 0, timer = null, genre = "All", signup = true, dModal;
const inList = id => list.includes(id), byId = id => titles.find(t => t.id === id);
const meta = t => `${t.genre} / ${t.year} / ${t.duration}`;
const pic = (t, c = "") => `<img ${c} src="${t.poster}" alt="Poster for ${t.title}" loading="lazy" width="400" height="600" onerror="this.onerror=null;this.src='${t.fallback}'">`;
const NAV = [["index", "Home"], ["browse", "Browse"], ["mylist", "My List"], ["about", "About and Help"]];

function shell() {
  $("#site-header").innerHTML = `<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="nav" aria-label="Main navigation"><div class="container-xl">
<a class="navbar-brand logo" href="index.html" aria-label="Kuena Stream home"><svg width="30" height="30" viewBox="0 0 30 30" aria-hidden="true"><rect x="5" y="5" width="20" height="20" transform="rotate(45 15 15)" fill="#f2b134"/><rect x="10" y="10" width="10" height="10" transform="rotate(45 15 15)" fill="#0f1226"/></svg> Kuena<span>Stream</span></a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu" aria-controls="menu" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="menu"><ul class="navbar-nav me-auto">${NAV.map(([p, t]) => `<li class="nav-item"><a class="nav-link${p === page ? " active" : ""}" href="${p}.html"${p === page ? ' aria-current="page"' : ""}>${t}${p === "mylist" ? ' <span class="badge rounded-pill" id="count">0</span>' : ""}</a></li>`).join("")}</ul>
<form class="d-flex gap-2 align-items-center" role="search" action="browse.html"><input id="q" name="q" class="form-control search" type="search" placeholder="Search titles" aria-label="Search titles"><a class="btn btn-accent" href="signin.html">Sign in</a></form></div></div></nav>`;
  $("#site-footer").innerHTML = `<div class="container-xl"><p class="mb-1">Kuena Stream is a student demo. No real accounts or payments.</p><p class="mb-0">Trailers: Blender Foundation open movies (CC BY 3.0) via YouTube. Photos: Picsum (Unsplash licence). Poster fallbacks and demo titles were created for this project.</p></div>`;
  document.body.insertAdjacentHTML("beforeend", `<div class="modal fade" id="detailsModal" tabindex="-1" aria-labelledby="dTitle" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content dark"><div class="modal-header border-0"><h2 class="modal-title h3" id="dTitle"></h2><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body" id="dBody"></div></div></div></div>
<div class="toast-container position-fixed bottom-0 end-0 p-3"><div id="toast" class="toast text-bg-dark" role="status" aria-live="polite" aria-atomic="true"><div class="d-flex"><div class="toast-body" id="toastMsg"></div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button></div></div></div>`);
  dModal = new bootstrap.Modal("#detailsModal");
  $("#count").textContent = list.length;
}
function card(t, full) {
  const on = inList(t.id), tag = t.trending ? "Trending" : t.year >= 2024 ? "New" : "";
  return `<article class="tcard"><div class="pw"><button class="poster" data-open="${t.id}" aria-label="View details for ${t.title}">${pic(t)}</button>${tag ? `<span class="tag">${tag}</span>` : ""}
<button class="heart${on ? " on" : ""}" data-list="${t.id}" aria-pressed="${on}" aria-label="${on ? "Remove" : "Add"} ${t.title} ${on ? "from" : "to"} My List">${on ? "\u2713" : "+"}</button></div>
<h3>${t.title}</h3><p class="meta">${meta(t)}</p>${full ? `<p class="desc">${t.description}</p>` : ""}</article>`;
}
function fill(sel, arr, full, wrap) {
  const n = $(sel);
  if (n) n.innerHTML = arr.map(t => wrap ? `<div class="col">${card(t, full)}</div>` : card(t, full)).join("");
}
function showHero(i) {
  const fs = titles.filter(t => t.featured);
  if (!fs.length) return;
  slide = (i + fs.length) % fs.length;
  const f = fs[slide], h = $("#hero");
  h.style.cssText = `--c1:${f.c[0]};--c2:${f.c[1]};--bd:url('${f.backdrop}')`;
  h.innerHTML = `<div class="container-xl hero-in"><div class="hero-copy"><p class="kicker">Featured / ${f.genre}</p><h1>${f.title}</h1><p class="lead">${f.description}</p><p class="meta mb-4">${f.year} / ${f.duration}</p>
<div class="d-flex flex-wrap gap-2"><button class="btn btn-accent btn-lg" data-open="${f.id}" data-play="1">Watch trailer</button><button class="btn btn-ghost btn-lg" data-list="${f.id}">${inList(f.id) ? "Remove from My List" : "Add to My List"}</button><button class="btn btn-ghost btn-lg" data-open="${f.id}">More info</button></div>
<div class="dots" role="group" aria-label="Featured titles">${fs.map((_, j) => `<button class="${j === slide ? "on" : ""}" data-slide="${j}" aria-label="Show featured title ${j + 1}"></button>`).join("")}</div></div>${pic(f, 'class="hero-img"')}</div>`;
}
function renderChips() {
  const n = $("#chips");
  if (n) n.innerHTML = ["All", ...new Set(titles.map(t => t.genre))].map(g => `<button class="chip${g === genre ? " active" : ""}" data-genre="${g}" aria-pressed="${g === genre}">${g}</button>`).join("");
}
function browse() {
  const q = $("#q").value.trim().toLowerCase(), yr = $("#year").value, so = $("#sort").value, out = [];
  for (const t of titles) {
    const okGenre = genre === "All" || t.genre === genre;
    const okText = !q || (t.title + " " + t.description).toLowerCase().includes(q);
    const okYear = yr === "all" || Math.floor(t.year / 10) * 10 === +yr;
    if (okGenre && okText && okYear) out.push(t);
  }
  out.sort(so === "az" ? (a, b) => a.title.localeCompare(b.title) : so === "old" ? (a, b) => a.year - b.year : (a, b) => b.year - a.year);
  $("#status").textContent = `Showing ${out.length} of ${titles.length} titles`;
  if (out.length) fill("#grid", out, true, true);
  else $("#grid").innerHTML = `<div class="empty">No titles match. Clear the search or choose another genre or decade.</div>`;
}
function myList() {
  const items = list.map(byId).filter(Boolean);
  $("#clear").hidden = !items.length;
  if (items.length) fill("#listGrid", items, true, true);
  else $("#listGrid").innerHTML = `<div class="empty"><p>Your list is empty. Select the + on any poster to save it here.</p><a href="browse.html" class="btn btn-accent">Browse titles</a></div>`;
}
function render() {
  $("#count").textContent = list.length;
  if (page === "index") {
    showHero(slide);
    fill("#trending", titles.filter(t => t.trending));
    fill("#newrel", titles.filter(t => t.year >= 2024));
    fill("#recs", titles.filter(t => !t.trending));
    const r = recent.map(byId).filter(Boolean);
    $("#recentWrap").hidden = !r.length; fill("#recent", r);
  }
  if (page === "browse") { renderChips(); browse(); }
  if (page === "mylist") myList();
}
function toast(msg) {
  $("#toastMsg").textContent = msg;
  bootstrap.Toast.getOrCreateInstance("#toast", { delay: 2200 }).show();
}
function toggle(id) {
  const t = byId(id);
  if (inList(id)) { list = list.filter(x => x !== id); toast(`${t.title} removed from My List`); }
  else { list.push(id); toast(`${t.title} added to My List`); }
  wr(KEY, list); render(); syncModal();
}
function syncModal() {
  const b = $("#mlBtn");
  if (b && cur) b.textContent = inList(cur.id) ? "Remove from My List" : "Add to My List";
}
function openDetails(id) {
  cur = byId(id);
  if (!cur) return;
  $("#dTitle").textContent = cur.title;
  $("#dBody").innerHTML = `<div class="row g-4"><div class="col-md-4">${pic(cur, 'class="img-fluid rounded-3"')}</div>
<div class="col-md-8"><p class="meta">${meta(cur)}</p><p>${cur.description}</p><div id="player" class="mb-3"></div>
<div class="d-flex flex-wrap gap-2">${cur.trailer ? `<button class="btn btn-accent" id="watch">Watch trailer</button><a class="btn btn-ghost" target="_blank" rel="noopener" href="https://www.youtube.com/watch?v=${cur.trailer}">Open on YouTube</a>` : `<button class="btn btn-accent" disabled>No trailer for this demo title</button>`}
<button class="btn btn-ghost" id="mlBtn" data-list="${cur.id}"></button></div></div></div>`;
  syncModal(); dModal.show();
}
function play() {
  if (!cur || !cur.trailer) return;
  $("#player").innerHTML = `<div class="ratio ratio-16x9"><iframe src="https://www.youtube-nocookie.com/embed/${cur.trailer}?autoplay=1" title="Trailer for ${cur.title}" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></div>`;
  recent = [cur.id, ...recent.filter(x => x !== cur.id)].slice(0, 6); wr(RK, recent);
  if (page === "index") render();
}
function bindForm(form, rules, done) {
  form.addEventListener("submit", e => {
    e.preventDefault();
    let ok = true;
    for (const [id, test, msg] of rules()) {
      const el = $("#" + id), good = test(el.value.trim());
      el.classList.toggle("is-invalid", !good); el.classList.toggle("is-valid", good);
      const fb = el.parentElement.querySelector(".invalid-feedback");
      if (fb) fb.textContent = msg;
      if (!good) ok = false;
    }
    if (ok) { form.reset(); form.querySelectorAll(".is-valid").forEach(x => x.classList.remove("is-valid")); done(); }
    else form.querySelector(".is-invalid").focus();
  });
  form.addEventListener("input", e => e.target.classList.remove("is-invalid"));
}
const okMail = v => /^\S+@\S+\.\S+$/.test(v);
function forms() {
  const cf = $("#contactForm");
  if (cf) bindForm(cf, () => [["cname", v => v.length >= 2, "Enter your name."], ["cemail", okMail, "Enter a valid email, like name@example.com."], ["cmsg", v => v.length >= 10, "Write at least 10 characters."]],
    () => { $("#cdone").innerHTML = `<div class="alert alert-success py-2">Thanks. This is a demo, so your message was not sent.</div>`; });
  const af = $("#authForm");
  if (!af) return;
  bindForm(af, () => [...(signup ? [["name", v => v.length >= 2, "Enter your full name."]] : []), ["email", okMail, "Enter a valid email, like name@example.com."], ["pw", v => v.length >= 8 && /\d/.test(v), "Use at least 8 characters, including one number."]],
    () => { $("#bar").style.width = "0"; $("#authDone").innerHTML = `<div class="alert alert-success py-2">Success. This is a demo, so no account was created.</div>`; });
  $("#pw").addEventListener("input", e => {
    const v = e.target.value, s = [v.length >= 8, /\d/.test(v), /[A-Z]/.test(v), /[^\w]/.test(v)].filter(Boolean).length;
    $("#bar").style.cssText = `width:${s * 25}%;background:${["#ff6b6b", "#ff6b6b", "#f2b134", "#9ad65b", "#1fae7a"][s]}`;
  });
  $("#showpw").addEventListener("click", e => {
    const p = $("#pw"), show = p.type === "password";
    p.type = show ? "text" : "password"; e.target.textContent = show ? "Hide" : "Show";
  });
  $("#swap").addEventListener("click", e => {
    e.preventDefault(); signup = !signup;
    $("#nameBox").hidden = !signup;
    $("#aTitle").textContent = signup ? "Create your account" : "Welcome back";
    $("#authBtn").textContent = signup ? "Create account" : "Sign in";
    e.target.textContent = signup ? "Already have an account? Sign in" : "New here? Create an account";
    $("#authDone").innerHTML = "";
  });
}
async function init() {
  shell(); forms();
  if (!["index", "browse", "mylist"].includes(page)) return;
  ["#trending", "#newrel", "#recs"].forEach(s => { const n = $(s); if (n) n.innerHTML = '<div class="sk"></div>'.repeat(6); });
  if (page === "browse") $("#q").value = new URLSearchParams(location.search).get("q") || "";
  try {
    const res = await fetch("data/titles.json");
    if (!res.ok) throw new Error("HTTP " + res.status);
    titles = await res.json();
  } catch (err) {
    titles = window.KUENA || [];
    const a = $("#alert");
    if (a) a.innerHTML = `<div class="alert alert-warning" role="alert">The catalogue file could not be fetched (${err.message}), so the built-in copy is shown. This happens when pages are opened straight from a folder. Run the site from a web server or the hosted link for the live JSON.</div>`;
  }
  render();
}
document.addEventListener("click", e => {
  const open = e.target.closest("[data-open]"), add = e.target.closest("[data-list]"), g = e.target.closest("[data-genre]"), dot = e.target.closest("[data-slide]");
  if (add) toggle(+add.dataset.list);
  else if (open) { openDetails(+open.dataset.open); if (open.dataset.play) play(); }
  else if (g) { genre = g.dataset.genre; renderChips(); browse(); }
  else if (dot) showHero(+dot.dataset.slide);
  else if (e.target.id === "watch") play();
  else if (e.target.id === "clear" && confirm("Remove every title from My List?")) { list = []; wr(KEY, list); render(); toast("My List cleared"); }
});
document.addEventListener("input", e => { if (page === "browse" && e.target.id === "q") browse(); });
document.addEventListener("change", e => { if (page === "browse" && ["year", "sort"].includes(e.target.id)) browse(); });
addEventListener("storage", e => { if (e.key === KEY) { list = rd(KEY); render(); } });
addEventListener("scroll", () => $("#nav").classList.toggle("solid", scrollY > 40), { passive: true });
if (page === "index" && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
  const go = () => { clearInterval(timer); timer = setInterval(() => titles.length && showHero(slide + 1), 7000); };
  go(); document.addEventListener("mouseover", e => e.target.closest(".hero") ? clearInterval(timer) : go());
}
$("#detailsModal")?.addEventListener("hidden.bs.modal", () => { $("#dBody").innerHTML = ""; });
init();
